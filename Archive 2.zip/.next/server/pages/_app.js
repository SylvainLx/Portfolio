(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 3847:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6764);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tailwind_config_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8010);
/* harmony import */ var _tailwind_config_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tailwind_config_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _postcss_config_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9442);
/* harmony import */ var _postcss_config_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_postcss_config_js__WEBPACK_IMPORTED_MODULE_3__);




function App({ Component , pageProps  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
        ...pageProps
    });
}


/***/ }),

/***/ 9442:
/***/ ((module) => {

"use strict";

module.exports = {
    plugins: {
        tailwindcss: {},
        autoprefixer: {},
        ... true ? {
            cssnano: {}
        } : 0
    }
};


/***/ }),

/***/ 8010:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
/** @type {import('tailwindcss').Config} */ 
const defaultTheme = __webpack_require__(5851);
module.exports = {
    content: [
        "./pages/**/*.{js,ts,jsx,tsx}",
        "./components/**/*.{js,ts,jsx,tsx}"
    ],
    theme: {
        extend: {
            animation: {
                type: "type 2.2s ease-out .8s infinite alternate both",
                "fade-in-right": "fade-in-right 1s ease-out",
                "fade-in-right2": "fade-in-right 1.2s ease-out",
                "fade-in-right3": "fade-in-right 1.4s ease-out",
                "fade-in-right4": "fade-in-right 1.6s ease-out",
                "fade-in-right5": "fade-in-right 1.8s ease-out",
                "fade-in-right6": "fade-in-right 2.0s ease-out",
                "fade-in-down": "fade-in-down 1s ease-out"
            },
            keyframes: {
                type: {
                    "0%": {
                        transform: "translateX(0ch)"
                    },
                    "5%, 10%": {
                        transform: "translateX(1ch)"
                    },
                    "15%, 20%": {
                        transform: "translateX(2ch)"
                    },
                    "25%, 30%": {
                        transform: "translateX(3ch)"
                    },
                    "35%, 40%": {
                        transform: "translateX(4ch)"
                    },
                    "45%, 50%": {
                        transform: "translateX(5ch)"
                    },
                    "55%, 60%": {
                        transform: "translateX(6ch)"
                    },
                    "65%, 100%": {
                        transform: "translateX(7ch)"
                    }
                },
                "fade-in-right": {
                    "0%": {
                        opacity: "0",
                        transform: "translateX(-60px)"
                    },
                    "100%": {
                        opacity: "1",
                        transform: "translateX(0)"
                    }
                },
                "fade-in-down": {
                    "0%": {
                        opacity: "0",
                        transform: "translateY(-60px)"
                    },
                    "100%": {
                        opacity: "1",
                        transform: "translateY(0)"
                    }
                }
            },
            backgroundImage: {
                backgroundInto: "url('../public/fondIntro.webp')"
            }
        }
    },
    plugins: []
};


/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5851:
/***/ ((module) => {

"use strict";
module.exports = require("tailwindcss/defaultTheme");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3847));
module.exports = __webpack_exports__;

})();
import CircleIcons from "./CircleIcons";

function Intro() {
  return (
    <div className="flex justify-center align-middle">
      <CircleIcons />
    </div>
  );
}

export default Intro;

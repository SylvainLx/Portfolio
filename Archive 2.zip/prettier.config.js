module.exports = {
  tailwindConfig: "./tailwind.config.js",
};
